#!/usr/bin/env python3
"""
Test script for the queue-based export system
"""

from graph_exporter import GraphExporter
from node_exporters import register_all_exporters
import json
import time

def test_mnist_export():
    """Test exporting a simple MNIST training workflow"""
    print("=" * 60)
    print("Test 1: MNIST Training Workflow")
    print("=" * 60)
    
    # Create exporter
    exporter = GraphExporter()
    register_all_exporters(exporter)
    
    # Test workflow - MNIST with two linear layers
    mnist_workflow = {
        "nodes": [
            {
                "id": "1",
                "class_type": "MNISTDataset",
                "inputs": {
                    "data_path": "./data",
                    "train": True,
                    "download": True,
                    "batch_size": 64,
                    "emit_rate": 5.0  # 5 batches per second
                }
            },
            {
                "id": "2", 
                "class_type": "LinearLayer",
                "inputs": {
                    "input_size": 784,
                    "output_size": 256,
                    "activation": "relu",
                    "dropout": 0.2
                }
            },
            {
                "id": "3",
                "class_type": "LinearLayer", 
                "inputs": {
                    "input_size": 256,
                    "output_size": 10,
                    "activation": "none"
                }
            },
            {
                "id": "4",
                "class_type": "Loss",
                "inputs": {
                    "loss_type": "cross_entropy"
                }
            }
        ],
        "links": [
            [1, "1", 0, "2", 0],  # MNIST data -> Linear1
            [2, "2", 0, "3", 0],  # Linear1 -> Linear2
            [3, "3", 0, "4", 0],  # Linear2 -> Loss (predictions)
            [4, "1", 1, "4", 1],  # MNIST labels -> Loss (labels)
        ],
        "metadata": {
            "name": "MNIST Classifier",
            "description": "Simple two-layer neural network for MNIST",
            "export_time": time.strftime("%Y-%m-%d %H:%M:%S")
        }
    }
    
    # Export
    script = exporter.export_workflow(mnist_workflow)
    
    # Save to file
    output_file = "test_mnist_queue.py"
    with open(output_file, "w") as f:
        f.write(script)
    
    print(f"✅ Exported MNIST workflow to: {output_file}")
    print(f"   Total lines: {len(script.splitlines())}")
    

def test_robotics_export():
    """Test exporting a robotics workflow with vision and sound"""
    print("\n" + "=" * 60)
    print("Test 2: Vision + Sound Robotics Workflow")
    print("=" * 60)
    
    # Create exporter
    exporter = GraphExporter()
    register_all_exporters(exporter)
    
    # Robotics workflow
    robotics_workflow = {
        "nodes": [
            {
                "id": "camera",
                "class_type": "CameraSensor",
                "inputs": {
                    "fps": 30.0,
                    "resolution": "640x480",
                    "use_real_camera": False
                }
            },
            {
                "id": "microphone", 
                "class_type": "AudioSensor",
                "inputs": {
                    "sample_rate": 16.0,
                    "channels": 2
                }
            },
            {
                "id": "vision_net",
                "class_type": "VisionNetwork",
                "inputs": {
                    "model": "resnet18",
                    "pretrained": True,
                    "device": "cuda"
                }
            },
            {
                "id": "sound_net",
                "class_type": "SoundNetwork", 
                "inputs": {
                    "model": "wav2vec",
                    "device": "cuda"
                }
            },
            {
                "id": "decision_net",
                "class_type": "DecisionNetwork",
                "inputs": {
                    "action_dim": 6,
                    "hidden_size": 512,
                    "device": "cuda"
                }
            },
            {
                "id": "robot_ctrl",
                "class_type": "RobotController",
                "inputs": {
                    "num_joints": 7,
                    "joint_limits": [-3.14, 3.14],
                    "control_type": "position"
                }
            }
        ],
        "links": [
            [1, "camera", 0, "vision_net", 0],      # Camera -> Vision
            [2, "microphone", 0, "sound_net", 0],   # Audio -> Sound
            [3, "vision_net", 0, "decision_net", 0], # Vision -> Decision
            [4, "sound_net", 0, "decision_net", 1],  # Sound -> Decision  
            [5, "decision_net", 0, "robot_ctrl", 0]  # Decision -> Robot
        ],
        "metadata": {
            "name": "Multimodal Robot Control",
            "description": "Vision and sound processing for robot decision making",
            "export_time": time.strftime("%Y-%m-%d %H:%M:%S")
        }
    }
    
    # Export
    script = exporter.export_workflow(robotics_workflow)
    
    # Save to file
    output_file = "test_robotics_queue.py"
    with open(output_file, "w") as f:
        f.write(script)
    
    print(f"✅ Exported robotics workflow to: {output_file}")
    print(f"   Total lines: {len(script.splitlines())}")
    

def test_simple_linear():
    """Test a minimal workflow"""
    print("\n" + "=" * 60)
    print("Test 3: Simple Linear Transform")
    print("=" * 60)
    
    # Create exporter
    exporter = GraphExporter()
    register_all_exporters(exporter)
    
    # Minimal workflow
    simple_workflow = {
        "nodes": [
            {
                "id": "data",
                "class_type": "MNISTDataset",
                "inputs": {
                    "batch_size": 32,
                    "emit_rate": 10.0
                }
            },
            {
                "id": "linear",
                "class_type": "LinearLayer",
                "inputs": {
                    "input_size": 784,
                    "output_size": 10
                }
            },
            {
                "id": "display",
                "class_type": "Display",
                "inputs": {
                    "display_type": "tensor_stats",
                    "log_interval": 5
                }
            }
        ],
        "links": [
            [1, "data", 0, "linear", 0],     # Data -> Linear
            [2, "linear", 0, "display", 0]   # Linear -> Display
        ],
        "metadata": {
            "name": "Simple Test",
            "export_time": time.strftime("%Y-%m-%d %H:%M:%S")
        }
    }
    
    # Export
    script = exporter.export_workflow(simple_workflow)
    
    # Save to file
    output_file = "test_simple_queue.py"
    with open(output_file, "w") as f:
        f.write(script)
    
    print(f"✅ Exported simple workflow to: {output_file}")
    print(f"   Total lines: {len(script.splitlines())}")


if __name__ == "__main__":
    print("🚀 DNNE Queue-Based Export System Tests")
    print("=" * 60)
    
    # Run all tests
    test_mnist_export()
    test_robotics_export()
    test_simple_linear()
    
    print("\n" + "=" * 60)
    print("✅ All tests completed!")
    print("\nGenerated scripts:")
    print("  - test_mnist_queue.py    : MNIST training with async queues")
    print("  - test_robotics_queue.py : Vision+Sound robotics control")
    print("  - test_simple_queue.py   : Simple linear transform demo")
    print("\nRun any script with: python <script_name>.py")
    print("Press Ctrl+C to stop the async execution.")
